public class Horse
{
    private int x;
    private int y;
    private int speed;
    private boolean jumping;

    public Horse(int startY)
    {
        x = 0;
        y = startY;
        speed = 10;
        jumping = false;
    }

    public void move()
    {
        x = x + speed;
    }

    public void jump()
    {
        jumping = true;
    }

    public void slowDown()
    {
        speed = 5;
    }

    public void speedUp()
    {
        speed = 20;
    }

    public void normalSpeed()
    {
        speed = 10;
    }

    public int getX()
    {
        return x;
    }
}